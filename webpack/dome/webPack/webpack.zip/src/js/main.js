function function_name(argument) {
		alert(66666666)
}