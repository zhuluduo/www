function ss(argument) {
	alert(555)
}