import tpl from './layer.html';
function layer() {
	return {
		name:'layer',
		tpl:tpl
	}
}

export default layer;