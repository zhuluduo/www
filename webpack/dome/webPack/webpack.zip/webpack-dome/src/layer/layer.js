function layer(){
	var voc={}
	voc={
		name:'alyer'
	}
	return voc;
}

export default layer;