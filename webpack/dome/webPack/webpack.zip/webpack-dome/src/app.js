import layer from './layer/layer.js'
const App=function(){
	console.log(layer)
}

new App();