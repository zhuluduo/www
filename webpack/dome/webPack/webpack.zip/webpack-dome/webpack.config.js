 const path=require('path');
 const HtmlWebpackPlugin=require('html-webpack-plugin');
 module.exports={
 	entry:{
 		app:'./src/app.js'
 	},
 	output:{
 		path:path.resolve(__dirname, 'dist'),
 		filename:'js/[name]-[chunkhash].js' 
 	},
 	module:{
 		rules :[
 		{
 			test:/\.js$/,
 			loader:'babel'
 		}
 		]
 	},
 


plugins:[
	new HtmlWebpackPlugin({
		filename:'index.html',
		template: 'index.html',
		inject:'body'
	})
]
}
