Component({
  properties: {
    item: {
      type: Object,
      value: {}
    },
  },
})