export const indexSearch = `大家都在搜“金秘书终于亲了”`;
export const mallSearch = `搜索小红书商品`;