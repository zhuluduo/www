const URL = {
  NoteTabbar:'NoteTabbar#!method=get',
  NoteDetail:'noteDetail#!method=get',
  GoodsTabbar:'GoodsTabbar#!method=get',
  goodDetail:'goodDetail#!method=get'
}

export {URL};