<?php
//检测用户名是否存在
$uname = $_POST['uname'];
file_put_contents('./check.txt', $uname);
//连接数据库，查询一下，这个用户是否存在（略）
//假设下面的用户已经存在
$users = array(
    'zhangsan',
    'lisi',
    'wangwu'
);
if(in_array($uname, $users)){
    //用户已经存在
    echo '<font color="red">sorry，用户名已经存在</font>';
}else{
    //用户不存在
    echo '<font color="green">恭喜，用户名可用</font>';
}
?>