<?php
$arr = array(
    'apple',
    'pen',
    'orange'
);
$arr1 = array(
    'laoda' => 'liubei',
    'laoer' => 'guanyu',
    'laosan' => 'zhangfei'
);
//print_r($arr);
$arr2 = array(
    array('id'=>1, 'name'=>'songjiang', 'nickname'=>'jishiyu'),
    array('id'=>2, 'name'=>'lujunyi', 'nickname'=>'yuqilin'),
    array('id'=>3, 'name'=>'wuyong', 'nickname'=>'zhiduoxing'),
);
$str = json_encode($arr2);
echo $str;
//$a = json_decode($str, true);
//print_r($a);


/*

[{'id':1, 'name':'songjiang', 'nickname':'jishiyu'},{},{}]

 */
?>