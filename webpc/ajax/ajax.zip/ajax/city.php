<?php
//连接数据库
$link = mysql_connect('localhost', 'root', '');
//mysql_select_db('itcast', $link);
mysql_query('use itcast');
mysql_query('set names utf8');


//根据type参数，来决定取什么信息
$type = $_GET['type'];
if($type == 'p'){
    //取得省的信息
    $sql = "select Pcode,Pname from province";
    $result = mysql_query($sql);
    $arr = array();
    while($row = mysql_fetch_assoc($result)){
        $arr[] = $row;
    }
    echo json_encode($arr);
}elseif($type == 'c'){
    //根据Pcode取出市的信息
    $Pcode = $_GET['Pcode'];
    $sql = "select Ccode,Cname from city where ProvinceCode = $Pcode";
    $result = mysql_query($sql);
    $arr = array();
    while($row = mysql_fetch_assoc($result)){
        $arr[] = $row;
    }
    echo json_encode($arr);
}elseif($type == 'a'){
    //根据Pcode取出市的信息
    $Ccode = $_GET['Ccode'];
    $sql = "select Acode,Aname from areacounty where CityCode = $Ccode";
    $result = mysql_query($sql);
    $arr = array();
    while($row = mysql_fetch_assoc($result)){
        $arr[] = $row;
    }
    echo json_encode($arr);
}
?>